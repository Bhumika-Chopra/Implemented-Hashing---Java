import java.lang.Math;

public class MyDHHashTable<K extends Comparable<T> ,T> implements MyHashTable_<K, T> {
	public static long hash1(String str, int hashtableSize) { 
	    long hash = 5381; 
	    for (int i = 0; i < str.length(); i++) { 
	        hash = ((hash << 5) + hash) + str.charAt(i); 
	    } 
	    return Math.abs(hash) % hashtableSize; 
	}
	public static long hash2(String str, int hashtableSize) { 
	    long hash = 0; 
	    for (int i = 0; i < str.length(); i++) { 
	        hash = str.charAt(i) + (hash << 6) + (hash << 16) - hash; 
	    } 
	    return Math.abs(hash) % (hashtableSize - 1) + 1; 
	}
	
	HashEntry<K,T>[] table;
	int size;

	//created a dummy to occupy space at the time of deletion
	HashEntry<K,T> dummy;
	@SuppressWarnings("unchecked")
	public MyDHHashTable(int T) {
		size = T;
		table = new HashEntry[size];
		for(int i=0; i<size; i++) {
			table[i] = null;
		}
		K t = (K) new Pair("*", "*");
		dummy = new HashEntry<K,T>(t, null);
	}
	@Override
	//no chance that i don't find a space for inserting.
	public int insert(K key, T obj) {
		if(this.contains(key)) {
			return -1;
		}
		else {
			long h1 = hash1(key.toString(), size);
			long h2 = hash2(key.toString(), size);
			int i=0;
//			boolean found = false;
			while(table[(int) h1] != null) {
				if(table[(int) h1].getkey().toString().compareTo(dummy.getkey().toString()) == 0) {
					break;
				}
				i++;
				h1 += h2;
				h1 %= size;
			}
			//insertion will always take place at a dummy index
			table[(int) h1] = new HashEntry<K,T>(key, obj);
			return i+1;
		}
	}

	@Override
	public int update(K key, T obj) {
		if(this.contains(key)) {
			long h1 = hash1(key.toString(), size);
			long h2 = hash2(key.toString(), size);
			int i=0;
//			boolean found = true;
			while(table[(int) h1].getkey().toString().compareTo(key.toString()) != 0) {
				i++;
				h1 += h2;
				h1 %= size;
			}
			table[(int) h1] = new HashEntry<K,T>(key, obj);
			return i+1;
		}
		else 
			//the key to be updated is not present in the hash table
			return -1;
	}

	@Override
	public int delete(K key) {
		if(this.contains(key)) {
			long h1 = hash1(key.toString(), size);
			long h2 = hash2(key.toString(), size);
			int i=0;
//			boolean found = true;
			while(table[(int) h1].getkey().toString().compareTo(key.toString()) != 0) {
				i++;
				h1 += h2;
				h1 %= size;
			}
			table[(int) h1] = this.dummy;
			//show error if not found
			return i+1;
		}
		else
			//the element to be deleted is not present in the table
			return -1;
	}

	@Override
	public boolean contains(K key) {
		long h1 = hash1(key.toString(), size);
		long h2 = hash2(key.toString(), size);
		int first = (int) h1;
		boolean found = false;
		int i = 0;
		while(table[(int) h1] != null) {
			if(table[(int) h1].getkey().toString().compareTo(key.toString()) == 0) {
				found = true;
				break;
			}
			i++;
			h1 += h2;
			h1 %= size;
			if(i == first) {
//				found = false;
				break;
			}
		}
		return found;
	}

	@Override
	public T get(K key) throws NotFoundException {
		if(this.contains(key)) {
			long h1 = hash1(key.toString(), size);
			long h2 = hash2(key.toString(), size);
			while(table[(int) h1].getkey().toString().compareTo(key.toString()) != 0) {
				h1 += h2;
				h1 %= size;
			}
			return table[(int) h1].getvalue();
		}
		else 
			//key is not present in the hash table
			throw new NotFoundException();
	}

	@Override
	public String address(K key) throws NotFoundException {
		if(this.contains(key)) {
			long h1 = hash1(key.toString(), size);
			long h2 = hash2(key.toString(), size);
			while(table[(int) h1].getkey().toString().compareTo(key.toString()) != 0) {
				h1 += h2;
				h1 %= size;
			}
			return Long.toString(h1);
		}
		else {
			throw new NotFoundException();
		}
	}
}