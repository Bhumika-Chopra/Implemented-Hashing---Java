
public class Pair implements Comparable<Student> {
	String fname;
	String lname;
	Pair(String f, String l) {
		fname = f;
		lname = l;
	}
	public String toString () {
		return (fname + "" + lname);
	}
//	public static boolean equals(Pair k1, Pair k2) {
//		return ( true == (k1.toString().equals(k2.toString())) );
//	}
//	public static void main(String args[]) {
//		Pair p = new Pair("Bhumika", "Chopra");
//		Pair q = new Pair("Bhumika1", "Chopra");
//		System.out.println(p.toString());
//		System.out.println(equals(p,q));
//	}
	@Override
	public int compareTo(Student other) {
		return this.fname.compareTo(other.toString());
	}
}
