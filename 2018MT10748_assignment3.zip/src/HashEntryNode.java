
public class HashEntryNode<K,T> {
	HashEntry<K,T> data;
	HashEntryNode<K, T> left;
	HashEntryNode<K, T> right;
	public HashEntryNode(HashEntry<K, T> data ) {
		this.data = data;
		left = right= null ;
	}
	public HashEntry<K, T> get() {
		return this.data;
	}
	public T getdata () {
		return this.data.getvalue();
	}
	public K getkey() {
		return this.data.getkey();
	}
}
