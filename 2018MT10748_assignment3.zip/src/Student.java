
public class Student implements Student_{
	String f;
	String l;
	String hos;
	String dep;
	String cg;
	public Student(String f, String l, String hos, String dep, String cg) {
		this.f = f;
		this.l = l;
		this.hos = hos;
		this.dep = dep;
		this.cg = cg;
		
	}
	@Override
	public String toString() {
		return this.f;
	}
	@Override
	public String fname() {
		return this.f;
	}

	@Override
	public String lname() {
		return this.l;
	}

	@Override
	public String hostel() {
		return this.hos;
	}

	@Override
	public String department() {
		return this.dep;
	}

	@Override
	public String cgpa() {
		return this.cg;
	}
//	@Override
//	public int compareTo(Student other) {
//		return this.toString().compareTo(other.toString());
//	}
}
