
public class MySCBSTHashTable<K extends Comparable<T>, T> implements MyHashTable_<K, T> {

	public static long hash1(String str, int hashtableSize) { 
	    long hash = 5381; 
	    for (int i = 0; i < str.length(); i++) { 
	        hash = ((hash << 5) + hash) + str.charAt(i); 
	    } 
	    return Math.abs(hash) % hashtableSize; 
	}
	
	BST<K, T>[] table;
	int size;
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public MySCBSTHashTable(int N) {
		size = N;
		table = new BST[size];
		for(int i=0; i<size; i++) 
			table[i] = new BST();
	}

	@Override
	public int insert(K key, T obj) {
		long h1 = hash1(key.toString(), size);
		//String f = convertstring(key.toString());
		return table[(int) h1].insert(key, obj);
	}

	@Override
	public int update(K key, T obj) {
		long h1 = hash1(key.toString(), size);
		//String f = convertstring(key.toString());
		return table[(int) h1].update(key, obj);
	}

	@Override
	public int delete(K key) {
		long h1 = hash1(key.toString(), size);
		//String f = convertstring(key.toString());
		return table[(int) h1].delete(key);
		
	}

	@Override
	public boolean contains(K key) {
		long h1 = hash1(key.toString(), size);
		return table[(int) h1].contains(key);
		
	}
	
	@Override
	public T get(K key) throws NotFoundException {
		long h1 = hash1(key.toString(), size);
		//String f = convertstring(key.toString());
		T t = table[(int) h1].get(key);
		if(t == null)
			throw new NotFoundException();
		else
			return t;	
	}

	@Override
	public String address(K key) throws NotFoundException {
		long h1 = hash1(key.toString(), size);
		String s1 = "";
		s1 += (int)h1 + "-";
		String s  = table[(int) h1].address(key, s1);
		if( s!= null)
			return s;
		else
			throw new NotFoundException();
	}
}
