
public class BST<K extends Comparable<T>,T> {
	HashEntryNode<K, T> root;
	static int insert = 0;
	static int j = 0;
	static String s = "";
	public BST() {
		root = null;
	}
	
	public int insert(K key, T obj) {
		insert = 0;
		if(contains(key)) {
			return -1;
		}
		else {
			root = insert(root, key, obj);
			return insert;
		}
	}
	
	public HashEntryNode<K, T> insert (HashEntryNode<K, T> node, K key, T obj) {
		if(node == null) {
			insert++;
			node = new HashEntryNode<K, T>(new HashEntry<K, T>(key, obj));
			return node;
		}
		if(key.compareTo(node.getdata()) > 0) {
			insert++;
			node.right = insert(node.right, key, obj);
		}
		else {
			insert++;
			node.left = insert(node.left, key, obj);
		}
		return node;
	}
	
	public boolean contains(K key) {
		return contains(root, key);
	}
	
	public boolean contains (HashEntryNode<K, T> node, K key) {
		if(node == null) 
			return false;
		else if(node.getkey().toString().compareTo(key.toString()) == 0) {
			return true;
		}
		else if(key.compareTo(node.getdata()) > 0) 
			return contains(node.right, key);
		else
			return contains(node.left, key);
	}
	
	public int update(K key, T obj) {
		if(contains(key)) {
			insert = 0;
	 		root = update(root, key, obj);
			return insert;
		}
		else {
			return -1;
		}
	}
	
	public HashEntryNode<K, T> update(HashEntryNode<K, T> node, K key, T obj) {
		if(node.getkey().toString().compareTo(key.toString()) == 0) {
			insert++;
			node.data = new HashEntry<K, T>(key, obj);
		}
		else if(key.compareTo(node.getdata()) > 0) {
			insert++;
			node.right =  update(node.right, key, obj);
		}
		else {
			insert++;
			node.left =  update(node.left, key, obj);
		}
		return node;
	}
	
	public T get(K key) {
		return get(root, key);
	}
	
	public T get(HashEntryNode<K, T> node, K key) {
		if(node == null) {
			return null;
		}
		else if(node.getkey().toString().compareTo(key.toString()) == 0) {
			return node.getdata();
		}
		else if(key.compareTo(node.getdata()) > 0) 
			return get(node.right, key);
		else
			return get(node.left, key);
	}
	
	public String address(K key, String s1) {
		if(contains(key)) {
			s = "";
			s1 += address(root, key);
			return s1;
		}
		else
			return null;
	}

	public String address(HashEntryNode<K, T> node, K key) {
		if(node == null) {
			return null;
		}
		if(node.getkey().toString().compareTo(key.toString()) == 0) {
			return s;
		}
		else if(key.compareTo(node.getdata()) > 0) {
			s += "R";
			return address(node.right, key);
		}
		else {
			s += "L";
			return address(node.left, key);
		}
	}
	
	public int delete(K key) {
		if(contains(key)) {
			insert = 0;
			root =  delete(root, key);
			return insert+1;
		}
		else
			return -1;
	}
	
	public HashEntryNode<K, T> delete(HashEntryNode<K, T> node, K key) {
		if(node.getkey().toString().compareTo(key.toString()) == 0) {
			if(node.right == null && node.left == null) {
				return null;
			}
			else if(node.right == null) {
				insert++;
				return node.left;
			}
			else if(node.left == null) {
				insert++;
				return node.right;
			}
			else {
//				node.data = findmin(node.right).data;
				HashEntryNode<K, T> succParent = node.right;
				insert++;
				HashEntryNode<K, T> succ = node.right;
				while(succ.left != null) {
					succParent = succ;
					succ = succ.left;
					insert++;
				}
//				j++;
				if(succ.right != null) 
					insert++;
				succParent.left = succ.right;
				node.data = succ.data;
				//node.right = delete(node.right, node.getkey());
			}
			
		}
		else if(key.compareTo(node.getdata()) > 0) {
//			if(j == 0)
			insert++;
			node.right = delete(node.right, key);
		}
		else {
//			if(j == 0)
			insert++;
			node.left = delete(node.left, key);
		}
		return node;
	}

	
//	public void print() {
//		printtree(root);
//	}
//	
//	public void printtree(HashEntryNode<K, T> node) {
//		if(node == null) {
//			return;
//		}
//		printtree(node.left);
//		System.out.println(node.getkey().toString());
//		printtree(node.right);
//	}
	
}
