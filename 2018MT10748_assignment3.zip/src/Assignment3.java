import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class Assignment3 {
	private static void maketable(String s1, String s2, String s3) {
		if(s2.equals("DH")) {
			BufferedReader br = null;
			try {
				br = new BufferedReader(new FileReader(s3));
				MyDHHashTable<Pair, Student> hashtable = new MyDHHashTable<Pair, Student>(Integer.parseInt(s1));
				String line = br.readLine();
				String[] details = null;
				while(line != null) {
					details = line.split(" ", 0);
					Pair key = new Pair(details[1], details[2]);
					if(details[0].equals("insert")) {
						Student stud = new Student(details[1], details[2], details[3], details[4], details[5]);
						int i = hashtable.insert(key, stud);
						if(i == -1)
							System.out.println("E");
						else
							System.out.println(i);
						
					}
					else if(details[0].equals("delete")) {
						int i = hashtable.delete(key);
						if(i == -1) 
							System.out.println("E");
						else {
							System.out.println(i);
						}
					}
					else if(details[0].equals("update")) {
						Student stud = new Student(details[1], details[2], details[3], details[4], details[5]);
						int i = hashtable.update(key, stud);
						if(i == -1)
							System.out.println("E");
						else
							System.out.println(i);
					}
					else if(details[0].equals("contains")) {
						if(hashtable.contains(key))
							System.out.println("T");
						else
							System.out.println("F");
					}
					else if(details[0].equals("get")) {
						try {
							Student stud = hashtable.get(key);
							System.out.println(stud.fname() + " " + stud.lname() + " " + stud.hostel() + " " + stud.department() + " " + stud.cgpa());
						}
						catch (NotFoundException e) {
							System.out.println("E");
						}
					}
					else if(details[0].equals("address")) {
						try {
							String st = hashtable.address(key);
							System.out.println(st);
						}
						catch (NotFoundException e) {
							System.out.println("E");
						}
					}
					line =  br.readLine();
				}
			}
			catch (IOException e) {
				e.printStackTrace();
			}
			finally {
				try {
					if(br != null)
						br.close();
				}
				catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		}
		else if(s2.equals("SCBST")) {
			BufferedReader br = null;
			try {
				br = new BufferedReader(new FileReader(s3));
				MySCBSTHashTable<Pair, Student> hashtable = new MySCBSTHashTable<Pair, Student>(Integer.parseInt(s1));
				String line = br.readLine();
				String[] details = null;
				while(line != null) {
					details = line.split(" ", 0);
					Pair key = new Pair(details[1], details[2]);
					if(details[0].equals("insert")) {
						Student stud = new Student(details[1], details[2], details[3], details[4], details[5]);
						int i = hashtable.insert(key, stud);
						if(i == -1)
							System.out.println("E");
						else
							System.out.println(i);
						
					}
					else if(details[0].equals("delete")) {
						int i = hashtable.delete(key);
						if(i == -1) 
							System.out.println("E");
						else {
							System.out.println(i);
						}
					}
					else if(details[0].equals("update")) {
						Student stud = new Student(details[1], details[2], details[3], details[4], details[5]);
						int i = hashtable.update(key, stud);
						if(i == -1)
							System.out.println("E");
						else
							System.out.println(i);
					}
					else if(details[0].equals("contains")) {
						if(hashtable.contains(key))
							System.out.println("T");
						else
							System.out.println("F");
					}
					else if(details[0].equals("get")) {
						try {
							Student stud = hashtable.get(key);
							System.out.println(stud.fname() + " " + stud.lname() + " " + stud.hostel() + " " + stud.department() + " " + stud.cgpa());
						}
						catch (NotFoundException e) {
							System.out.println("E");
						}
					}
					else if(details[0].equals("address")) {
						try {
							String st = hashtable.address(key);
							System.out.println(st);
						}
						catch (NotFoundException e) {
							System.out.println("E");
						}
					}
					line =  br.readLine();
				}
			}
			catch (IOException e) {
				e.printStackTrace();
			}
			finally {
				try {
					if(br != null)
						br.close();
				}
				catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		}
	}

	public static void main(String args[]) {
		maketable(args[0], args[1], args[2]);
	}
}
