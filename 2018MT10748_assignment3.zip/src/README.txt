We use hash tables to store data having large values of keys.
In this assignment we have used 2 implementations of hash table - 1) Binary Search Tree Separate chaining 2) Open addressing - double hashing
Using amortized analysis we find the time complexities to for insertion, deletion, updation, get, address, contains operations to be O(1), i.e. these operations occur in constant time. But this is true only when the table size is chosen appropriately. 
In our case it has been ensured that the table size, T, will be from [1.5N, 2N], where N is the input size for the case of double hashing. Also T will be prime number. When T is a prime number it ensures that before coming back to the same index (hash value) again we would have probed all the other indices once, and therefore if it was going to find an empty index for insertion, or the key to be deleted; it must have already found so. Hence, having T as prime number reduces the number and chances of collisions.

Assuming that the hash functions are calculating the hash value in O(1) time, they are also returning distinct hash values so as to minimize collisions and they are distributing the hash values uniformly thoroughtout the table - 
	
	public static long hash1(String str, int hashtableSize) {  			//djb2
	    long hash = 5381; 
	    for (int i = 0; i < str.length(); i++) { 
	        hash = ((hash << 5) + hash) + str.charAt(i); 
	    } 
	    return Math.abs(hash) % hashtableSize; 
	}

	
	public static long hash2(String str, int hashtableSize) { 			//sdbm
	    long hash = 0; 
	    for (int i = 0; i < str.length(); i++) { 
	        hash = str.charAt(i) + (hash << 6) + (hash << 16) - hash; 
	    } 
	    return Math.abs(hash) % (hashtableSize - 1) + 1; 
	}

Theoretical average time complexities for double hashing implemented hash table - 
Insertion - O(1)
Deletion - O(1)
Updation - O(1)
contains, get, address - O(1)

On comparing with my code - 

contains() - 

	public boolean contains(K key) {
		long h1 = hash1(key.toString(), size);
		long h2 = hash2(key.toString(), size);
		int first = (int) h1;
		boolean found = false;
		int i = 0;
		while(table[(int) h1] != null) {
			if(table[(int) h1].getkey().toString().compareTo(key.toString()) == 0) {
				found = true;
				break;
			}
			i++;
			h1 += h2;
			h1 %= size;
			if(i == first) {
				break;
			}
		}
		return found;
	}

The function takes a key and checks if the key is present in the hash table or not. When the key we're searching for is not present in the hash table, in that case the searching time becomes worst, i.e. is approximately O(n) seeing as our hash function will check all indices before arriving at the intial index again. I have put my termination condition as when I reach the index whose value is equal to my first calculated hash index - first, i.e. I have traversed all the indices once before coming back to the same index again. If I still didn't find the element then it is not in the hash table. 
Average and best time complexity = O(1)
Worst case time complexity = O(T) , where T is the table size.

get() - 
	public T get(K key) throws NotFoundException {
		if(this.contains(key)) {
			long h1 = hash1(key.toString(), size);
			long h2 = hash2(key.toString(), size);
			while(table[(int) h1].getkey().toString().compareTo(key.toString()) != 0) {
				h1 += h2;
				h1 %= size;
			}
			return table[(int) h1].getvalue();
		}
		else 
			//key is not present in the hash table
			throw new NotFoundException();
	}

address() - 
	public String address(K key) throws NotFoundException {
		if(this.contains(key)) {
			long h1 = hash1(key.toString(), size);
			long h2 = hash2(key.toString(), size);
			while(table[(int) h1].getkey().toString().compareTo(key.toString()) != 0) {
				h1 += h2;
				h1 %= size;
			}
			return Long.toString(h1);
		}
		else {
			throw new NotFoundException();
		}

Both the get() and address() function work in similar fashion as to the contains() function. So,
average and best case time complexity = O(1)
worst case time complexity = O(T) - T is table size - when the key is not in the hash table.

delete() -
	public int delete(K key) {
		if(this.contains(key)) {
			long h1 = hash1(key.toString(), size);
			long h2 = hash2(key.toString(), size);
			int i=0;
//			boolean found = true;
			while(table[(int) h1].getkey().toString().compareTo(key.toString()) != 0) {
				i++;
				h1 += h2;
				h1 %= size;
			}
			table[(int) h1] = this.dummy;
			return i+1;
		}
		else
			//the element to be deleted is not present in the table
			return -1;
	}

insert() - 
	public int insert(K key, T obj) {
		if(this.contains(key)) {
			return -1;
		}
		else {
			long h1 = hash1(key.toString(), size);
			long h2 = hash2(key.toString(), size);
			int i=0;
			while(table[(int) h1] != null) {
				if(table[(int) h1].getkey().toString().compareTo(dummy.getkey().toString()) == 0) {
					break;
				}
				i++;
				h1 += h2;
				h1 %= size;
			}
			table[(int) h1] = new HashEntry<K,T>(key, obj);
			return i+1;
		}
	}

update() -
	public int update(K key, T obj) {
		if(this.contains(key)) {
			long h1 = hash1(key.toString(), size);
			long h2 = hash2(key.toString(), size);
			int i=0;
			while(table[(int) h1].getkey().toString().compareTo(key.toString()) != 0) {
				i++;
				h1 += h2;
				h1 %= size;
			}
			table[(int) h1] = new HashEntry<K,T>(key, obj);
			return i+1;
		}
		else 
			//the key to be updated is not present in the hash table
			return -1;
	}

The delete, update, insert function all work in the same manner. Assuming that the hash functions are good, i.e. they give hash values so as to cause minumum collisions then the actual number of indices that we will have to traverse while inserting, deleting, updating is a constant number, which will be much less than the table size assuming that T is a prime number.
average and best case time complexity = O(1)
worst case time complexity = O(T) - T is table size - when the key is not in the hash table.



Theoretical average time complexities for separate chaining via binary search tree implemented hash table - 

We can calculate the load factor L = (N/T) - where N - is the number of elements to be inserted and T is the hash table size.
Assuming that the binary trees that are constructed at each index value are height balanced or small enough that balancing will not make a difference then the approximate height of the binary tree will be O(log(L)). h = O(log(L)).
Insertion - O(h)
Deletion - O(h)
Updation - O(h)
contains, get, address - O(h)

On comparing with my code - 

I have implemented my BST recursively.

contains() - 

public boolean contains(K key) {
		return contains(root, key);
	}
	
	public boolean contains (HashEntryNode<K, T> node, K key) {
		if(node == null) 
			return false;
		else if(node.getkey().toString().compareTo(key.toString()) == 0) {
			return true;
		}
		else if(key.compareTo(node.getdata()) > 0) 
			return contains(node.right, key);
		else
			return contains(node.left, key);
	}

For locating the element I will do inorder traversal to the tree and return true if it is present, else return false. h - height of the tree 
Average case time complexity = O(h)
Worst case time complexity = O(L) - L - the load factor - is the assumed number of total elements in the tree. This happens when all the elements enter one child of one parent, i.e. a linked list is constructed effecively and the tree is unbalanced.

update() -

public int update(K key, T obj) {
		if(contains(key)) {
			insert = 0;
	 		root = update(root, key, obj);
			return insert;
		}
		else {
			return -1;
		}
	}
	
	public HashEntryNode<K, T> update(HashEntryNode<K, T> node, K key, T obj) {
		if(node.getkey().toString().compareTo(key.toString()) == 0) {
			insert++;
			node.data = new HashEntry<K, T>(key, obj);
		}
		else if(key.compareTo(node.getdata()) > 0) {
			insert++;
			node.right =  update(node.right, key, obj);
		}
		else {
			insert++;
			node.left =  update(node.left, key, obj);
		}
		return node;
	}
	
get() -

	public T get(K key) {
		return get(root, key);
	}
	
	public T get(HashEntryNode<K, T> node, K key) {
		if(node == null) {
			return null;
		}
		else if(node.getkey().toString().compareTo(key.toString()) == 0) {
			return node.getdata();
		}
		else if(key.compareTo(node.getdata()) > 0) 
			return get(node.right, key);
		else
			return get(node.left, key);
	}
	
address() -
 
	public String address(K key, String s1) {
		if(contains(key)) {
			s = "";
			s1 += address(root, key);
			return s1;
		}
		else
			return null;
	}

	public String address(HashEntryNode<K, T> node, K key) {
		if(node == null) {
			return null;
		}
		if(node.getkey().toString().compareTo(key.toString()) == 0) {
			return s;
		}
		else if(key.compareTo(node.getdata()) > 0) {
			s += "R";
			return address(node.right, key);
		}
		else {
			s += "L";
			return address(node.left, key);
		}
	}

the update(), insert(), get(), address()  functions work in a manner similar to contains() and therefore -
Average case time complexity = O(h)
Worst case time complexity = O(L) - L - the load factor - is the assumed number of total elements in the tree. This happens when all the elements enter one child of one parent, i.e. a linked list is constructed effectively and the tree is unbalanced.

delete() - 

	public int delete(K key) {
		if(contains(key)) {
			insert = 0;
			root =  delete(root, key);
			return insert+1;
		}
		else
			return -1;
	}
	
	public HashEntryNode<K, T> delete(HashEntryNode<K, T> node, K key) {
		if(node.getkey().toString().compareTo(key.toString()) == 0) {
			if(node.right == null && node.left == null) {
				return null;
			}
			else if(node.right == null) {
				insert++;
				return node.left;
			}
			else if(node.left == null) {
				insert++;
				return node.right;
			}
			else {
//				node.data = findmin(node.right).data;
				HashEntryNode<K, T> succParent = node.right;
				insert++;
				HashEntryNode<K, T> succ = node.right;
				while(succ.left != null) {
					succParent = succ;
					succ = succ.left;
					insert++;
				}
//				j++;
				if(succ.right != null) 
					insert++;
				succParent.left = succ.right;
				node.data = succ.data;
				//node.right = delete(node.right, node.getkey());
			}
			
		}
		else if(key.compareTo(node.getdata()) > 0) {
//			if(j == 0)
			insert++;
			node.right = delete(node.right, key);
		}
		else {
//			if(j == 0)
			insert++;
			node.left = delete(node.left, key);
		}
		return node;
	}

In case of deletion() there are 3 cases - 
i) node to be deleted is leaf node = delete directly
ii) node to be deleted has only 1 child = promote that child
iii) node to be deleted has 2 children = then find the immediate successor (or immediate predecessor), copy its data to the node to be deleted and delete the immediate successor (or immediate predecessor). 

Also in deletion as well -
Average case time complexity = O(h)
Worst case time complexity = O(L) - L - the load factor - is the assumed number of total elements in the tree. This happens when all the elements enter one child of one parent, i.e. a linked list is constructed effectively and the tree is unbalanced.

Separate chaining and double hashing both have their advantages and disadvantages, from what I observed - 
In double hashing it is easier to insert and update nodes (get, address, contains) in comparison to separate chaining. While deletion in case of separate chaining is better beacuse after deletion we don't have to store dummy markers in the hash table. Essentially once we have performed a large number of deletion operations on the hash table in case of double hashing, then we have created many dummy markers which are being traversed each time we want to search for or delete some other node, hence the time complexity does not remain O(1) and we may have to rehash the table. In case of SCBST the only difficulty is when multiple keys get hashed to a common index, then the searching, insertion, deletion, get, address, contains functions - all their time complexities increase.
Also in case of double hashing we maintain an array of fixed size initially so each time the load factor becomes greater than 0.5 it is necessary to rehash the table, this process take O(T) time where T is the original table size, this is not required in separate chaining.
In general for larger inputs when the load factor becomes greater than 0.75 separate chaining becomes better than double hashing, for load factors less than this double hashing is better. 
