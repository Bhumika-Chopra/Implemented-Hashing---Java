
public class HashEntry<K,T> {
	K key;
	T value;
	public HashEntry(K k, T v) {
		key = k;
		value = v;
	}
	public K getkey() {
		return this.key;
	}
	public T getvalue() {
		return this.value;
	}
//	@Override
//	public int compareTo(HashEntry<K, T> other) {
//		return (this.getkey()).compareTo(other.getkey());
//	}
}
